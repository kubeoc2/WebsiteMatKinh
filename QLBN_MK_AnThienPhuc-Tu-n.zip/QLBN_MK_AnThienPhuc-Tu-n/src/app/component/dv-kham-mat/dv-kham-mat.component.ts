import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dv-kham-mat',
  templateUrl: './dv-kham-mat.component.html',
  styleUrls: ['./dv-kham-mat.component.scss']
})
export class DvKhamMatComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
