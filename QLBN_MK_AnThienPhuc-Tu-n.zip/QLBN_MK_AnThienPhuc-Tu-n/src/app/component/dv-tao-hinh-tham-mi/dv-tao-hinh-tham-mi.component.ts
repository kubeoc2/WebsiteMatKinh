import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dv-tao-hinh-tham-mi',
  templateUrl: './dv-tao-hinh-tham-mi.component.html',
  styleUrls: ['./dv-tao-hinh-tham-mi.component.scss']
})
export class DvTaoHinhThamMiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
