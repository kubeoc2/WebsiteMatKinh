import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dv-dieu-tri-tat-khuc-xa',
  templateUrl: './dv-dieu-tri-tat-khuc-xa.component.html',
  styleUrls: ['./dv-dieu-tri-tat-khuc-xa.component.scss']
})
export class DvDieuTriTatKhucXaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
