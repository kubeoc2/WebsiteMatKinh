import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dv-phau-thuat-glaucoma',
  templateUrl: './dv-phau-thuat-glaucoma.component.html',
  styleUrls: ['./dv-phau-thuat-glaucoma.component.scss']
})
export class DvPhauThuatGlaucomaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
