import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ve-chung-toi',
  templateUrl: './ve-chung-toi.component.html',
  styleUrls: ['./ve-chung-toi.component.scss']
})
export class VeChungToiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
