import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dv-phau-thuat-khuc-xa',
  templateUrl: './dv-phau-thuat-khuc-xa.component.html',
  styleUrls: ['./dv-phau-thuat-khuc-xa.component.scss']
})
export class DvPhauThuatKhucXaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
