import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quanlibackend',
  templateUrl: './quanlibackend.component.html',
  styleUrls: ['./quanlibackend.component.scss']
})
export class QuanlibackendComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
